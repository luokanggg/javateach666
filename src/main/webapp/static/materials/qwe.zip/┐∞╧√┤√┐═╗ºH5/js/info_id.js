(function($) {


        var p = $('#imagepicker1').imagePicker({
            //label: '请上传身份证正面',
            bgImage: 'images/ID_face_z.png',
            //datas: ['http://172.30.0.86/dcloud/api/v1/document/download?docid=1EE5542E-A7AF-47BA-8DFD-7D4E3785B689&filename=葛春月-1.jpg'],
            //onlyCamera: true,
            //onSubmit: true
            onSuccess: function(file, data){
                console.log(file);
                console.log(data);
            }
        });
        $('#imagepicker2').imagePicker({
            //label: '请上传身份证反面',
            bgImage: 'images/ID_face_f.png',
            //onlyCamera: true,
            //onSubmit: true
            onSuccess: function(file, data){
                console.log(file);
                console.log(data);
            },
            onDelete: function(){
                console.log("shangchu");
            }
        });
        $('#imagepicker3').imagePicker({
            //label: '请上传身份证反面',
            bgImage: 'images/hht_zz.png',
            //onlyCamera: true,
            //onSubmit: true
            onSuccess: function(file, data){
                console.log(file);
                console.log(data);
            },
            onDelete: function(){
                console.log("shangchu");
            }
        });
        $('#imagepicker4').imagePicker({
            //label: '请上传身份证反面',
            bgImage: 'images/bank.png',
            //onlyCamera: true,
            //onSubmit: true
            onSuccess: function(file, data){
                console.log(file);
                console.log(data);
            },
            onDelete: function(){
                console.log("shangchu");
            }
        });

})($);