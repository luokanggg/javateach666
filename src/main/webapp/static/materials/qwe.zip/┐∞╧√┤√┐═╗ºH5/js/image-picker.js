;(function($) {
    var ImagePicker = function(el, options) {
        var p = this;
        var defaults = {
            isList: false,
            field: 'file',  /*文件上传控件name*/
            label: '',  /*选择框显示标签*/
            labelColor: '#fff', /*标签颜色*/
            labelPosition: 'bottom', /*标签在选择框中的位置，可选 'top', 'middle', 'bottom'*/
            bgImage: '', /*选择框背景图片*/
            uploadUrl: 'http://t.hanhua.com/dcloud/api/v1/document/addfile', /*上传地址，默认filenet*/
            datas: [], /*默认显示的图片,数组*/
            params: null, /*其他需要在上传时提供的参数，jsonObject*/
            errorText: '上传失败', /*错误提示*/
            onlyCamera: false, /*是否仅支持拍照 */
            onSubmit: false, /*false直接上传，true点击提交后上传(需要将控件放置在form表单中),仅在isList为false时有效*/
            onDelete: function() {},  /*删除照片时的回调*/
            onError: function(file, error) {}, /*发生错误时回调*/
            onSuccess: function(file, data) {} /*成功时回调*/
        };
        p.container = $(el);
        p.options = $.extend({}, defaults, options);
        p.file = null;
        p.fileinput = null;
        
        p.init =  function() {
            var labelP = p.options.labelPosition == 'top'?'top:10%;':(p.options.labelPosition == 'middle'?'bottom:45%;':'bottom:10%;');
            var inputbox_tpl = '<div class="ip-inputbox" style="background-image: url(' + p.options.bgImage + ');">'
                            +      '<span class="ip-inputbox_label" style="color:' + p.options.labelColor + ';' + labelP +'">' + p.options.label + '</span>'
                            +      '<div class="ip-inputbox_tips"></div>'
                            +  '</div>';
            var input_tpl = '<input class="ip-input" type="file" accept="image/*" name="' + p.options.field + '">';
            if(p.options.isList) {
                var ul_tpl = '<ul class="ip-list"></ul>';
                var $ul = $(ul_tpl).appendTo(p.container);
                if(Array.isArray(p.options.datas) && p.options.datas.length>0) {
                    for(var indx in p.options.datas) {
                        var item = '<li class="ip-list_item" style="background-image: url(' + p.options.datas[indx] + ')"><div class="ip-inputbox_tips"></div></li>'
                        $ul.append(item);
                    }
                }
                p.inputbox = $(inputbox_tpl).appendTo(p.container).addClass('ip-list_input');
                p.fileinput = $(input_tpl).appendTo(p.container);
                $ul.find('.ip-list_item').click(function() {
                    p.preview(this);
                });
            } else {
                p.inputbox = $(inputbox_tpl).appendTo(p.container);
                p.fileinput = $(input_tpl).appendTo(p.container);
                if(Array.isArray(p.options.datas) && p.options.datas.length>0) {
                    p.file = p.options.datas[0];
                    p.inputbox.css({ 'background-image' : 'url(' + p.options.datas[0] + ')' });
                    p.inputbox.find('.ip-inputbox_label').css({ display: "none" });
                }
            }
            
            p.inputbox.click(function() {
                if(p.options.isList || !p.file) {
                    if(p.options.onlyCamera) p.fileinput.attr("capture","camera").click(); //只支持拍照
                    else p.fileinput.click(); //拍照相册选择
                }
                else p.preview(this);
            });
            p.fileinput.change(function(e) {
                p.handleInputChange(e);
            });
            if(p.options.onSubmit === true && p.options.isList === false) {
                p.handleFormSumission();
            }
        };
        
        p.clearFileInput =  function() {
            var $input = p.container.find('input');
            var $clone = $input.clone().val('');
            $clone.change(function(e){
                p.handleInputChange(e);
            });
            $input.after($clone);
            $input.remove();
            p.fileinput = $clone;
        };
        
        p.handleInputChange = function(e) {
            p.file = e.target.files[0];
            if(p.file) {
                var reader = new FileReader();
                reader.readAsDataURL(p.file);
                reader.onload = function() {
                    if(p.options.isList) {
                        var item = '<li class="ip-list_item" style="background-image: url(' + reader.result + ')"><div class="ip-inputbox_tips"></div></li>'
                        var $litem = $(item).appendTo(p.container.find('ul'));
                        $litem.click(function(){
                            p.preview(this);
                        });
                        p.upload(p.file, $litem);
                    } else {
                        p.inputbox.css({ 'background-image' : 'url(' + reader.result + ')' });
                        p.inputbox.find('.ip-inputbox_label').css({ display: "none" });
                        if(p.options.onSubmit == false) {
                            p.upload(p.file, p.inputbox);
                        }
                    }
                };
            }
        };
        
        p.handleFormSumission = function() {
            var form = p.container.parent("form");
            if(form) {
                form.submit(function() {
                    if (p.file) {
                        p.upload(p.file);
                    } 
                    return true;
                });
            }
        };
        
        p.preview = function(el) {
            var $el = $(el);
            var ptpl = '<div class="weui-gallery" style="display: block">'
                    +    '<span class="weui-gallery__img"></span>'
                    +    '<div class="weui-gallery__opr">'
                    +        '<a href="javascript:" class="weui-gallery__del">' 
                    +            '<i class="weui-icon-delete weui-icon_gallery-delete"></i>'
                    +        '</a>'
                    +    '</div>'
                    + '</div>';
            var $browser = $(ptpl).appendTo(document.body);
            $browser.find('.weui-gallery__img').css({ 'background-image' : $el.css("backgroundImage") });
            $browser.find('.weui-gallery__del').click(function() {
                var result = confirm('您确定要删除这张图片吗？');
                if(result==true){
                    $browser.remove();
                    p.file = null;
                    p.clearFileInput();
                    if(p.options.isList){
                        $el.remove();
                    } else {
                        $el.css({ 'background-image' : 'url(' + p.options.bgImage + ')' });
                        p.container.find('.ip-inputbox_label').css({ display: "block" });
                    }
                    p.options.onDelete && p.options.onDelete();
                };
            });
            $browser.find('.weui-gallery__img').click(function() {
                $browser.remove();
            });
                    
        };
        
        p.showActionSheet = function() {
            var actions = [{ 
                    text:"拍照", 
                    onClick: function(){
                        p.container.find('input').attr("capture","camera").click();
                    }
                }, { 
                    text:"相册", 
                    onClick: function(){
                        p.container.find('input').click();
                    }
                }];
            $.actions({ actions: actions });
        };
        
        p.showError = function(error, $el) {
            p.file = null;
            p.clearFileInput();
            var hint = '<i class="weui-icon-warn"></i>' + error;
            $el.find('.ip-inputbox_tips').html(hint).css({ display: "flex" });
        };
        
        p.upload = function(file, $el) {
            var formData = new FormData();
            formData.append(p.options.field, file);
            formData.append("filename", file.name);
            for (var key in p.options.params) {
                formData.append(key, p.options.params[key]);
            }
            $.ajax({
                url: p.options.uploadUrl,
                type: "POST",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    if (data && data.code == '200') {
                        var hint = '<i class="weui-icon-success-no-circle" style="color:#fff;"></i>上传成功';
                        $el.find('.ip-inputbox_tips').html(hint).css({ display: "flex" });
                        setTimeout(function() {
                            $el.find('.ip-inputbox_tips').css({ display: "none" });
                        }, 3000);
                        p.options.onSuccess(file, data);
                    } else {
                        var err = null;
                        if (data.message) {
                            err = message;
                        } else {
                            err = p.options.errorText;
                        }
                        p.showError(p.options.errorText, $el);
                        p.options.onError(file, err);
                    }
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    p.showError(p.options.errorText, $el);
                    p.options.onError(file, thrownError);
                },
                xhr: function() {
                    myXhr = $.ajaxSettings.xhr();
                    if (myXhr.upload) {
                        myXhr.upload.addEventListener("progress", function(e) {
                            p.handleProgress(e, $el);
                        }, false);
                    }
                    return myXhr;
                }
            });
        };
        
        p.handleProgress = function(e, $el) {
            if (e.lengthComputable) {
                var total = e.total;
                var loaded = e.loaded;
                var percent = Number((e.loaded * 100 / e.total).toFixed(0));
                var hint = '<i class="ip-loading"></i>' + percent + '%';
                $el.find('.ip-inputbox_tips').html(hint).css({ display: "flex" });
            }
        };
        
        return p;
    };
    
    $.fn.imagePicker = function(options) {
        return this.each(function() {
            if(!this) return;
            var imagePicker = new ImagePicker(this, options);
            imagePicker.init();
        });
    };
})(jQuery);
